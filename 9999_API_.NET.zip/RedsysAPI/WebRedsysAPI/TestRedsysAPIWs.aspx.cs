﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Text;
using RedsysAPIPrj;
using System.Xml;
using System.Xml.Linq;

 
namespace WebRedsysAPI
{
    public partial class TestRedsysAPIWs : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {


            // Create a new Redsys Web service instance. To do this it is neccesary to add 
            // a new Web References with SerClsWSEntrada.wsdl (Web Services Description Language) file. 
            WebRedsysWs.SerClsWSEntradaService s = new WebRedsysWs.SerClsWSEntradaService();

            

            // Create a new instance of auxiliary class RedsysAPIWs
            RedsysAPIWs r = new RedsysAPIWs();

            // Main Key
            var kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7";
            //Parameters. 
            //This is an example. Use your own parameter
            var fuc = "999008881";
            var terminal = "30";
            var currency="978";
            // Transaction Type (A Pago Tradicional)
            var trans="A";
            // Amount
            var amount="145";
            // Card Number
            string pan = "4548812049400004";
            // Security PIN
            string cvv2="123";
            // Format YYMM
            string expire ="2012";
            /// Generate DATOSENTRADA information
            string dataEntrada = r.GenerateDatoEntradaXML(amount, fuc, currency, pan, cvv2, trans, terminal, expire);
       
            /// Calculate signature with main key and DATOSENTRADA information previously calculate
            string signature = r.createMerchantSignatureHostToHost(kc, dataEntrada);

            
            // Create final XML string with DATOSENTRADA and Signature previously calculated
            string requestXML = r.GenerateRequestXML(dataEntrada, signature);

            // Use the method trataPeticion of Web service
            string result = s.trataPeticion(requestXML);

            

            // Write the XML into textarea
            text1.Value = result;
            
            // Convert de XML string to Dictionary
            r.XMLToDiccionary(result);
            
            // Generate string cadena 
            string cadena = r.GenerateCadena(result);
            
            // Get Signature response from dictionary
            string signatureReceived = r.GetDictionary("Ds_Signature");

            // Get Ds_Order from dictionary
            string numOrder = r.GetDictionary("Ds_Order");

            // Get Calculate signature with main key (kc), cadena string and number of order ("Ds_Order")
            string signatureCalculate = r.createSignatureResponseHostToHost(kc, cadena, numOrder);

            // Check if received signature is equal to calculated signature
            if (signatureCalculate == signatureReceived)
            {

                resultSig.InnerHtml ="Signature OK";
            }
            else
            {
                resultSig.InnerHtml ="Signature KO";
            }

            StringBuilder str = new StringBuilder();

            string Rcodigo = "CODIGO"; 
            string Ramount = "Ds_Amount";
            string RCurrency ="Ds_Currency";
            string ROrder="Ds_Order";
            string RSignature="Ds_Signature";
            string RMerchantCode="Ds_MerchantCode";
            string RTerminal="Ds_Terminal";
            string RResponse = "Ds_Response";
            string RAuthoCode = "Ds_AuthorisationCode";
            string RTransType=  "Ds_TransactionType";
            string RSecure = "Ds_SecurePayment";
            string RLanguage ="Ds_Language";
            string RMerchantData= "Ds_MerchantData";
            string RCountry ="Ds_Card_Country";

            str.AppendLine(Rcodigo+": ");
            str.AppendLine(r.GetDictionary(Rcodigo));
            str.AppendLine(Ramount + ": ");
            str.AppendLine(r.GetDictionary(Ramount));
            str.AppendLine(RCurrency + ": ");
            str.AppendLine(r.GetDictionary(RCurrency));
            str.AppendLine(ROrder + ": ");
            str.AppendLine(r.GetDictionary(ROrder));
            str.AppendLine(RSignature + ": ");
            str.AppendLine(r.GetDictionary(RSignature));
            str.AppendLine(RMerchantCode + ": ");
            str.AppendLine(r.GetDictionary(RMerchantCode));
            str.AppendLine(RTerminal + ": ");
            str.AppendLine(r.GetDictionary(RTerminal));
            str.AppendLine(RResponse + ": ");
            str.AppendLine(r.GetDictionary(RResponse));
            str.AppendLine(RAuthoCode + ": ");
            str.AppendLine(r.GetDictionary(RAuthoCode));
            str.AppendLine(RTransType + ": ");
            str.AppendLine(r.GetDictionary(RTransType));
            str.AppendLine(RSecure + ": ");
            str.AppendLine(r.GetDictionary(RSecure));
            str.AppendLine(RLanguage + ": ");
            str.AppendLine(r.GetDictionary(RLanguage));
            str.AppendLine(RMerchantData + ": ");
            str.AppendLine(r.GetDictionary(RMerchantData));
            str.AppendLine(RCountry + ": ");
            str.AppendLine(r.GetDictionary(RCountry));

            // Write into textarea the parameter of XML response from dictionary
            text2.Value = str.ToString();
        
        
        }
    }
}