﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RedsysAPIPrj;
using System.IO;
using System.Windows;

namespace WebRedsysAPI
{
    public partial class TestRedsysNotif : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string version="";
            string data="";
            string signatureReceived="";

            // Using main key registered
            var kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7";
           
            // New instance of RedsysAPI
            RedsysAPI r = new RedsysAPI();


            // Obtain Ds_SignatureVersion using post
            if (Request.Form["Ds_SignatureVersion"] != null)
            {

                version = Request.Form["Ds_SignatureVersion"];
            
            
            }
            // Obtain Ds_MerchantParameters using post
            if (Request.Form["Ds_MerchantParameters"] != null)
            {

                data = Request.Form["Ds_MerchantParameters"];


            }

            // Obtan Ds_Signature using post
            if (Request.Form["Ds_Signature"] != null)
            {

                signatureReceived = Request.Form["Ds_Signature"];


            }
           
            // Decode Base 64 data
            string deco = r.decodeMerchantParameters(data);


            // Get Signature notificacion
            string notif = r.createMerchantSignatureNotif(kc, data);

            //sigRecv.Value = signatureReceived;
            // Check if signature received is the same than signature notificacion previously calculated
            string text = "";
            if (notif == signatureReceived && notif !="")
            {
             
                text = "SIGNATURE OK";
                
            }
            else
            {
               text = "SIGNATURE KO";
            }

           // write into file the result of checking signature and reply JSON  
           // This is an example, use your own path.
            const string fic = @"C:\Trabajo\RedsysAPI\WebRedsysAPI\test.txt";
            try
            {
                StreamWriter sw = new System.IO.StreamWriter(fic);
                sw.WriteLine("JSON:");
                sw.WriteLine(deco);
                sw.WriteLine("CHECK SIGNATURE:");
                sw.WriteLine(text);
                sw.Close();
                
            }
            catch (IOException ex)
            {
                throw new IOException(ex.Message);
            }
        }
    }
}