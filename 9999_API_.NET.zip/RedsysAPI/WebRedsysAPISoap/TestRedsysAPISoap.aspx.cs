﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RedsysAPIPrj;


namespace WebRedsysAPI
{
    public partial class TestRedsysAPISoap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            string version = "HMAC_SHA256_V1";
            
            // New instance of RedysAPI
            RedsysAPI r = new RedsysAPI();
            
            //Parameters. This is an example. Use your own parameters
            var fuc = "999008881";
            var terminal = "30";
            var currency="978";
	        var trans="0";
            //This is the url of SOAP merchant service. This is an example use your own url
			// In url is the path of InotificacionSIS.asmx
            var url = "";
            // OK url 
			var urlOK = "";
            // KO url
			var urlKO = "";
           // Generate randomly with Customer's platform
            var id = "1234567891";
            // Amount
			var amount="100";
            
            // Main Key 
            var kc = "sq7HjrUOBfKmC576ILgskD5srU870gJ7";
            // Fill Ds_MerchantParameters parameters
            r.SetParameter("DS_MERCHANT_AMOUNT", amount);
            r.SetParameter("DS_MERCHANT_ORDER", id);
            r.SetParameter("DS_MERCHANT_MERCHANTCODE", fuc);
            r.SetParameter("DS_MERCHANT_CURRENCY", currency);
            r.SetParameter("DS_MERCHANT_TRANSACTIONTYPE", trans);
            r.SetParameter("DS_MERCHANT_TERMINAL", terminal);
            r.SetParameter("DS_MERCHANT_MERCHANTURL", url);
            r.SetParameter("DS_MERCHANT_URLOK", urlOK);
            r.SetParameter("DS_MERCHANT_URLKO", urlKO);

            // Calculate Ds_SignatureVersion
            Ds_SignatureVersion.Value = version;
            // Calculate Ds_MerchantParameters
           string parms =  r.createMerchantParameters();
            Ds_MerchantParameters.Value = parms;
           
            // Calculate Ds_Signature
           string sig = r.createMerchantSignature(kc);
            Ds_Signature.Value = sig;

        }

       
    }
}